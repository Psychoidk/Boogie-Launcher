﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Boogie.Utils;
using Microsoft.WindowsAPICodePack.Dialogs;
using RestSharp;

namespace Hybrid
{
	// Token: 0x02000005 RID: 5
	public partial class MainWindow : Window
	{
		// Token: 0x06000015 RID: 21 RVA: 0x000020B4 File Offset: 0x000002B4
		public MainWindow()
		{
			RestClient restClient = new RestClient("https://backend.boogiefn.dev/");
			RestRequest restRequest = new RestRequest("/versioncheck?version=1.0.1", 0);
			string content = restClient.Execute(restRequest).Content;
			if (content == "Update Required")
			{
				MessageBox.Show("Oops! Looks like Boogie Launcher has a new update! Join discord.gg/fortnitedev to get the latest update!");
			}
			if (content != "Update Required")
			{
				this.InitializeComponent();
			}
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00002120 File Offset: 0x00000320
		private void AuthCode_Focus(object sender, RoutedEventArgs e)
		{
			MainWindow.<AuthCode_Focus>d__1 <AuthCode_Focus>d__;
			<AuthCode_Focus>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AuthCode_Focus>d__.<>4__this = this;
			<AuthCode_Focus>d__.<>1__state = -1;
			<AuthCode_Focus>d__.<>t__builder.Start<MainWindow.<AuthCode_Focus>d__1>(ref <AuthCode_Focus>d__);
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00002158 File Offset: 0x00000358
		private void AuthCode_UnFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.<AuthCode_UnFocus>d__2 <AuthCode_UnFocus>d__;
			<AuthCode_UnFocus>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AuthCode_UnFocus>d__.<>4__this = this;
			<AuthCode_UnFocus>d__.<>1__state = -1;
			<AuthCode_UnFocus>d__.<>t__builder.Start<MainWindow.<AuthCode_UnFocus>d__2>(ref <AuthCode_UnFocus>d__);
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002190 File Offset: 0x00000390
		private void Login_Click(object sender, RoutedEventArgs e)
		{
			if (!(this.LoginButton.Content.ToString() == "Login"))
			{
				if (this.LoginButton.Content.ToString() == "Launch!")
				{
					CommonOpenFileDialog commonOpenFileDialog = new CommonOpenFileDialog();
					commonOpenFileDialog.Title = "Please select the path for 21.10";
					commonOpenFileDialog.IsFolderPicker = true;
					commonOpenFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
					commonOpenFileDialog.AddToMostRecentlyUsedList = false;
					commonOpenFileDialog.AllowNonFileSystemItems = false;
					commonOpenFileDialog.DefaultDirectory = "Desktop";
					commonOpenFileDialog.EnsureFileExists = true;
					commonOpenFileDialog.EnsurePathExists = true;
					commonOpenFileDialog.EnsureReadOnly = false;
					commonOpenFileDialog.EnsureValidNames = true;
					commonOpenFileDialog.Multiselect = false;
					commonOpenFileDialog.ShowPlacesList = true;
					if (commonOpenFileDialog.ShowDialog() == 1)
					{
						string fileName = commonOpenFileDialog.FileName;
						string str = fileName + "\\FortniteGame\\Binaries\\Win64";
						if (!File.Exists(str + "/FortniteClient-Win64-Shipping.exe"))
						{
							MessageBox.Show("The path selected does not have Fortnite installed correctly: " + fileName + "\\nPlease retry with a valid path");
						}
						if (File.Exists(str + "/FortniteClient-Win64-Shipping.exe"))
						{
							WebClient webClient = new WebClient();
							string text = fileName + "\\FortniteGame\\Binaries\\Win64\\ReksFN.dll";
							webClient.DownloadFile("https://cdn.discordapp.com/attachments/954515979658989588/1015505286573871185/Rekeine_Dll.dll", text);
							Process.Start("https://discord.gg/fortnitedev");
							string fileName2 = Path.Combine(fileName, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe");
							string fileName3 = Path.Combine(fileName, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping_EAC.exe");
							string fileName4 = Path.Combine(fileName, "FortniteGame\\Binaries\\Win64\\FortniteLauncher.exe");
							string arguments = "-AUTH_LOGIN=unused -AUTH_PASSWORD=" + this.exchange + " -AUTH_TYPE=exchangecode -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=3db3ba5dcbd2e16703f3978d -caldera=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoiYmU5ZGE1YzJmYmVhNDQwN2IyZjQwZWJhYWQ4NTlhZDQiLCJnZW5lcmF0ZWQiOjE2Mzg3MTcyNzgsImNhbGRlcmFHdWlkIjoiMzgxMGI4NjMtMmE2NS00NDU3LTliNTgtNGRhYjNiNDgyYTg2IiwiYWNQcm92aWRlciI6IkVhc3lBbnRpQ2hlYXQiLCJub3RlcyI6IiIsImZhbGxiYWNrIjpmYWxzZX0.VAWQB67RTxhiWOxx7DBjnzDnXyyEnX7OljJm-j2d88G_WgwQ9wrE6lwMEHZHjBd1ISJdUO1UVUqkfLdU5nofBQ - skippatchcheck";
							Process process = new Process
							{
								StartInfo = new ProcessStartInfo(fileName2, arguments)
								{
									UseShellExecute = false,
									RedirectStandardOutput = false,
									CreateNoWindow = true
								}
							};
							Process process2 = new Process();
							process2.StartInfo.FileName = fileName4;
							process2.Start();
							foreach (object obj in process2.Threads)
							{
								ProcessThread processThread = (ProcessThread)obj;
								win32.SuspendThread(win32.OpenThread(2, false, processThread.Id));
							}
							Process process3 = new Process();
							process3.StartInfo.FileName = fileName3;
							process3.StartInfo.Arguments = "-epiclocale = en - nobe - fromfl = eac - fltoken = 3db3ba5dcbd2e16703f3978d - caldera = eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoiYmU5ZGE1YzJmYmVhNDQwN2IyZjQwZWJhYWQ4NTlhZDQiLCJnZW5lcmF0ZWQiOjE2Mzg3MTcyNzgsImNhbGRlcmFHdWlkIjoiMzgxMGI4NjMtMmE2NS00NDU3LTliNTgtNGRhYjNiNDgyYTg2IiwiYWNQcm92aWRlciI6IkVhc3lBbnRpQ2hlYXQiLCJub3RlcyI6IiIsImZhbGxiYWNrIjpmYWxzZX0.VAWQB67RTxhiWOxx7DBjnzDnXyyEnX7OljJm - j2d88G_WgwQ9wrE6lwMEHZHjBd1ISJdUO1UVUqkfLdU5nofBQ";
							process3.Start();
							foreach (object obj2 in process3.Threads)
							{
								ProcessThread processThread2 = (ProcessThread)obj2;
								win32.SuspendThread(win32.OpenThread(2, false, processThread2.Id));
							}
							process.Start();
							Thread.Sleep(2000);
							Thread.Sleep(6000);
							File.Delete(fileName + "\\FortniteGame\\Binaries\\Win64\\Injector.exe");
							webClient.DownloadFile("https://cdn.discordapp.com/attachments/823233042788122685/828311722036690984/Injector.exe", fileName + "\\FortniteGame\\Binaries\\Win64\\Injector.exe");
							process.WaitForInputIdle();
							new Process
							{
								StartInfo = 
								{
									Arguments = string.Format("\"{0}\" \"{1}\"", process.Id, text),
									CreateNoWindow = true,
									UseShellExecute = false,
									FileName = fileName + "\\FortniteGame\\Binaries\\Win64\\Injector.exe"
								}
							}.Start();
							Thread.Sleep(10);
							process.WaitForExit();
							try
							{
								process2.Close();
								process3.Close();
							}
							catch
							{
							}
							this.LoginButton.Content = "Login";
							this.LoggedInAs.Content = " ";
						}
					}
				}
				return;
			}
			this.LoggedInAs.Content = "Logging in...";
			RestClient restClient = new RestClient("https://e01a4dfd-fc0a-4703-a22a-cd2bc83bfaf1.id.repl.co/");
			string text2 = this.AuthCode.Text;
			RestRequest restRequest = new RestRequest("/exchange?code=" + text2, 0);
			this.exchange = restClient.Execute(restRequest).Content;
			this.exchangecode.Content = this.exchange;
			if (this.exchange.ToString() == "[]")
			{
				MessageBox.Show("The authorization code you supplied was invalid, please try again with a valid code!");
				return;
			}
			this.LoggedInAs.Content = "Successfully Logged in to Boogie! You can launch now!";
			this.LoginButton.Content = "Launch!";
		}

		// Token: 0x0400000A RID: 10
		private string exchange = "";
	}
}
