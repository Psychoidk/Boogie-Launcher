﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;

namespace Costura
{
	// Token: 0x0200000A RID: 10
	[CompilerGenerated]
	internal static class AssemblyLoader
	{
		// Token: 0x06000026 RID: 38 RVA: 0x0000281E File Offset: 0x00000A1E
		private static string CultureToString(CultureInfo culture)
		{
			if (culture == null)
			{
				return "";
			}
			return culture.Name;
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00002830 File Offset: 0x00000A30
		private static Assembly ReadExistingAssembly(AssemblyName name)
		{
			AppDomain currentDomain = AppDomain.CurrentDomain;
			Assembly[] assemblies = currentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				AssemblyName name2 = assembly.GetName();
				if (string.Equals(name2.Name, name.Name, StringComparison.InvariantCultureIgnoreCase) && string.Equals(AssemblyLoader.CultureToString(name2.CultureInfo), AssemblyLoader.CultureToString(name.CultureInfo), StringComparison.InvariantCultureIgnoreCase))
				{
					return assembly;
				}
			}
			return null;
		}

		// Token: 0x06000028 RID: 40 RVA: 0x000028A0 File Offset: 0x00000AA0
		private static void CopyTo(Stream source, Stream destination)
		{
			byte[] array = new byte[81920];
			int count;
			while ((count = source.Read(array, 0, array.Length)) != 0)
			{
				destination.Write(array, 0, count);
			}
		}

		// Token: 0x06000029 RID: 41 RVA: 0x000028D4 File Offset: 0x00000AD4
		private static Stream LoadStream(string fullName)
		{
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			if (fullName.EndsWith(".compressed"))
			{
				using (Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(fullName))
				{
					using (DeflateStream deflateStream = new DeflateStream(manifestResourceStream, CompressionMode.Decompress))
					{
						MemoryStream memoryStream = new MemoryStream();
						AssemblyLoader.CopyTo(deflateStream, memoryStream);
						memoryStream.Position = 0L;
						return memoryStream;
					}
				}
			}
			return executingAssembly.GetManifestResourceStream(fullName);
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00002958 File Offset: 0x00000B58
		private static Stream LoadStream(Dictionary<string, string> resourceNames, string name)
		{
			string fullName;
			if (resourceNames.TryGetValue(name, out fullName))
			{
				return AssemblyLoader.LoadStream(fullName);
			}
			return null;
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00002978 File Offset: 0x00000B78
		private static byte[] ReadStream(Stream stream)
		{
			byte[] array = new byte[stream.Length];
			stream.Read(array, 0, array.Length);
			return array;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x000029A0 File Offset: 0x00000BA0
		private static Assembly ReadFromEmbeddedResources(Dictionary<string, string> assemblyNames, Dictionary<string, string> symbolNames, AssemblyName requestedAssemblyName)
		{
			string text = requestedAssemblyName.Name.ToLowerInvariant();
			if (requestedAssemblyName.CultureInfo != null && !string.IsNullOrEmpty(requestedAssemblyName.CultureInfo.Name))
			{
				text = requestedAssemblyName.CultureInfo.Name + "." + text;
			}
			byte[] rawAssembly;
			using (Stream stream = AssemblyLoader.LoadStream(assemblyNames, text))
			{
				if (stream == null)
				{
					return null;
				}
				rawAssembly = AssemblyLoader.ReadStream(stream);
			}
			using (Stream stream2 = AssemblyLoader.LoadStream(symbolNames, text))
			{
				if (stream2 != null)
				{
					byte[] rawSymbolStore = AssemblyLoader.ReadStream(stream2);
					return Assembly.Load(rawAssembly, rawSymbolStore);
				}
			}
			return Assembly.Load(rawAssembly);
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00002A60 File Offset: 0x00000C60
		public static Assembly ResolveAssembly(object sender, ResolveEventArgs e)
		{
			object obj = AssemblyLoader.nullCacheLock;
			lock (obj)
			{
				if (AssemblyLoader.nullCache.ContainsKey(e.Name))
				{
					return null;
				}
			}
			AssemblyName assemblyName = new AssemblyName(e.Name);
			Assembly assembly = AssemblyLoader.ReadExistingAssembly(assemblyName);
			if (assembly != null)
			{
				return assembly;
			}
			assembly = AssemblyLoader.ReadFromEmbeddedResources(AssemblyLoader.assemblyNames, AssemblyLoader.symbolNames, assemblyName);
			if (assembly == null)
			{
				object obj2 = AssemblyLoader.nullCacheLock;
				lock (obj2)
				{
					AssemblyLoader.nullCache[e.Name] = true;
				}
				if ((assemblyName.Flags & AssemblyNameFlags.Retargetable) != AssemblyNameFlags.None)
				{
					assembly = Assembly.Load(assemblyName);
				}
			}
			return assembly;
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00002B38 File Offset: 0x00000D38
		// Note: this type is marked as 'beforefieldinit'.
		static AssemblyLoader()
		{
			AssemblyLoader.assemblyNames.Add("af-za.modernwpf.controls.resources", "costura.af-za.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("af-za.modernwpf.resources", "costura.af-za.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("am-et.modernwpf.controls.resources", "costura.am-et.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("am-et.modernwpf.resources", "costura.am-et.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ar-sa.modernwpf.controls.resources", "costura.ar-sa.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ar-sa.modernwpf.resources", "costura.ar-sa.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("az-latn-az.modernwpf.controls.resources", "costura.az-latn-az.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("az-latn-az.modernwpf.resources", "costura.az-latn-az.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("be-by.modernwpf.controls.resources", "costura.be-by.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("be-by.modernwpf.resources", "costura.be-by.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("bg-bg.modernwpf.controls.resources", "costura.bg-bg.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("bg-bg.modernwpf.resources", "costura.bg-bg.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("bn-bd.modernwpf.controls.resources", "costura.bn-bd.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("bn-bd.modernwpf.resources", "costura.bn-bd.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("bs-latn-ba.modernwpf.controls.resources", "costura.bs-latn-ba.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("bs-latn-ba.modernwpf.resources", "costura.bs-latn-ba.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ca-es.modernwpf.controls.resources", "costura.ca-es.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ca-es.modernwpf.resources", "costura.ca-es.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("commonwin32", "costura.commonwin32.dll.compressed");
			AssemblyLoader.symbolNames.Add("commonwin32", "costura.commonwin32.pdb.compressed");
			AssemblyLoader.assemblyNames.Add("costura", "costura.costura.dll.compressed");
			AssemblyLoader.symbolNames.Add("costura", "costura.costura.pdb.compressed");
			AssemblyLoader.assemblyNames.Add("cs-cz.modernwpf.controls.resources", "costura.cs-cz.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("cs-cz.modernwpf.resources", "costura.cs-cz.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("da-dk.modernwpf.controls.resources", "costura.da-dk.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("da-dk.modernwpf.resources", "costura.da-dk.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("de-de.modernwpf.controls.resources", "costura.de-de.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("de-de.modernwpf.resources", "costura.de-de.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("el-gr.modernwpf.controls.resources", "costura.el-gr.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("el-gr.modernwpf.resources", "costura.el-gr.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("en-gb.modernwpf.controls.resources", "costura.en-gb.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("en-gb.modernwpf.resources", "costura.en-gb.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("es-es.modernwpf.controls.resources", "costura.es-es.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("es-es.modernwpf.resources", "costura.es-es.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("es-mx.modernwpf.controls.resources", "costura.es-mx.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("es-mx.modernwpf.resources", "costura.es-mx.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("et-ee.modernwpf.controls.resources", "costura.et-ee.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("et-ee.modernwpf.resources", "costura.et-ee.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("eu-es.modernwpf.controls.resources", "costura.eu-es.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("eu-es.modernwpf.resources", "costura.eu-es.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fa-ir.modernwpf.controls.resources", "costura.fa-ir.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fa-ir.modernwpf.resources", "costura.fa-ir.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fi-fi.modernwpf.controls.resources", "costura.fi-fi.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fi-fi.modernwpf.resources", "costura.fi-fi.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fluentwpf", "costura.fluentwpf.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fr-ca.modernwpf.controls.resources", "costura.fr-ca.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fr-ca.modernwpf.resources", "costura.fr-ca.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fr-fr.modernwpf.controls.resources", "costura.fr-fr.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("fr-fr.modernwpf.resources", "costura.fr-fr.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("gl-es.modernwpf.controls.resources", "costura.gl-es.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("gl-es.modernwpf.resources", "costura.gl-es.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ha-latn-ng.modernwpf.controls.resources", "costura.ha-latn-ng.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ha-latn-ng.modernwpf.resources", "costura.ha-latn-ng.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("he-il.modernwpf.controls.resources", "costura.he-il.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("he-il.modernwpf.resources", "costura.he-il.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("hi-in.modernwpf.controls.resources", "costura.hi-in.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("hi-in.modernwpf.resources", "costura.hi-in.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("hr-hr.modernwpf.controls.resources", "costura.hr-hr.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("hr-hr.modernwpf.resources", "costura.hr-hr.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("hu-hu.modernwpf.controls.resources", "costura.hu-hu.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("hu-hu.modernwpf.resources", "costura.hu-hu.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("id-id.modernwpf.controls.resources", "costura.id-id.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("id-id.modernwpf.resources", "costura.id-id.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("is-is.modernwpf.controls.resources", "costura.is-is.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("is-is.modernwpf.resources", "costura.is-is.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("it-it.modernwpf.controls.resources", "costura.it-it.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("it-it.modernwpf.resources", "costura.it-it.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ja-jp.modernwpf.controls.resources", "costura.ja-jp.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ja-jp.modernwpf.resources", "costura.ja-jp.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ka-ge.modernwpf.controls.resources", "costura.ka-ge.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ka-ge.modernwpf.resources", "costura.ka-ge.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("kk-kz.modernwpf.controls.resources", "costura.kk-kz.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("kk-kz.modernwpf.resources", "costura.kk-kz.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("km-kh.modernwpf.controls.resources", "costura.km-kh.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("km-kh.modernwpf.resources", "costura.km-kh.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("kn-in.modernwpf.controls.resources", "costura.kn-in.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("kn-in.modernwpf.resources", "costura.kn-in.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ko-kr.modernwpf.controls.resources", "costura.ko-kr.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ko-kr.modernwpf.resources", "costura.ko-kr.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("lo-la.modernwpf.controls.resources", "costura.lo-la.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("lo-la.modernwpf.resources", "costura.lo-la.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("lt-lt.modernwpf.controls.resources", "costura.lt-lt.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("lt-lt.modernwpf.resources", "costura.lt-lt.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("lv-lv.modernwpf.controls.resources", "costura.lv-lv.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("lv-lv.modernwpf.resources", "costura.lv-lv.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("microsoft.bcl.asyncinterfaces", "costura.microsoft.bcl.asyncinterfaces.dll.compressed");
			AssemblyLoader.assemblyNames.Add("microsoft.toolkit.uwp.notifications", "costura.microsoft.toolkit.uwp.notifications.dll.compressed");
			AssemblyLoader.symbolNames.Add("microsoft.toolkit.uwp.notifications", "costura.microsoft.toolkit.uwp.notifications.pdb.compressed");
			AssemblyLoader.assemblyNames.Add("microsoft.windowsapicodepack", "costura.microsoft.windowsapicodepack.dll.compressed");
			AssemblyLoader.assemblyNames.Add("microsoft.windowsapicodepack.shell", "costura.microsoft.windowsapicodepack.shell.dll.compressed");
			AssemblyLoader.assemblyNames.Add("mk-mk.modernwpf.controls.resources", "costura.mk-mk.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("mk-mk.modernwpf.resources", "costura.mk-mk.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ml-in.modernwpf.controls.resources", "costura.ml-in.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ml-in.modernwpf.resources", "costura.ml-in.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("modernwpf.controls", "costura.modernwpf.controls.dll.compressed");
			AssemblyLoader.assemblyNames.Add("modernwpf", "costura.modernwpf.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ms-my.modernwpf.controls.resources", "costura.ms-my.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ms-my.modernwpf.resources", "costura.ms-my.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("nb-no.modernwpf.controls.resources", "costura.nb-no.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("nb-no.modernwpf.resources", "costura.nb-no.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("nl-nl.modernwpf.controls.resources", "costura.nl-nl.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("nl-nl.modernwpf.resources", "costura.nl-nl.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("nn-no.modernwpf.controls.resources", "costura.nn-no.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("nn-no.modernwpf.resources", "costura.nn-no.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("pl-pl.modernwpf.controls.resources", "costura.pl-pl.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("pl-pl.modernwpf.resources", "costura.pl-pl.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("pt-br.modernwpf.controls.resources", "costura.pt-br.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("pt-br.modernwpf.resources", "costura.pt-br.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("pt-pt.modernwpf.controls.resources", "costura.pt-pt.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("pt-pt.modernwpf.resources", "costura.pt-pt.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("restsharp", "costura.restsharp.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ro-ro.modernwpf.controls.resources", "costura.ro-ro.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ro-ro.modernwpf.resources", "costura.ro-ro.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ru-ru.modernwpf.controls.resources", "costura.ru-ru.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ru-ru.modernwpf.resources", "costura.ru-ru.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sk-sk.modernwpf.controls.resources", "costura.sk-sk.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sk-sk.modernwpf.resources", "costura.sk-sk.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sl-si.modernwpf.controls.resources", "costura.sl-si.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sl-si.modernwpf.resources", "costura.sl-si.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sq-al.modernwpf.controls.resources", "costura.sq-al.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sq-al.modernwpf.resources", "costura.sq-al.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sr-latn-rs.modernwpf.controls.resources", "costura.sr-latn-rs.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sr-latn-rs.modernwpf.resources", "costura.sr-latn-rs.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sv-se.modernwpf.controls.resources", "costura.sv-se.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sv-se.modernwpf.resources", "costura.sv-se.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sw-ke.modernwpf.controls.resources", "costura.sw-ke.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("sw-ke.modernwpf.resources", "costura.sw-ke.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.buffers", "costura.system.buffers.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.diagnostics.diagnosticsource", "costura.system.diagnostics.diagnosticsource.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.memory", "costura.system.memory.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.numerics.vectors", "costura.system.numerics.vectors.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.runtime.compilerservices.unsafe", "costura.system.runtime.compilerservices.unsafe.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.text.encodings.web", "costura.system.text.encodings.web.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.text.json", "costura.system.text.json.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.threading.tasks.extensions", "costura.system.threading.tasks.extensions.dll.compressed");
			AssemblyLoader.assemblyNames.Add("system.valuetuple", "costura.system.valuetuple.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ta-in.modernwpf.controls.resources", "costura.ta-in.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("ta-in.modernwpf.resources", "costura.ta-in.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("te-in.modernwpf.controls.resources", "costura.te-in.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("te-in.modernwpf.resources", "costura.te-in.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("th-th.modernwpf.controls.resources", "costura.th-th.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("th-th.modernwpf.resources", "costura.th-th.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("tr-tr.modernwpf.controls.resources", "costura.tr-tr.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("tr-tr.modernwpf.resources", "costura.tr-tr.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("uk-ua.modernwpf.controls.resources", "costura.uk-ua.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("uk-ua.modernwpf.resources", "costura.uk-ua.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("uz-latn-uz.modernwpf.controls.resources", "costura.uz-latn-uz.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("uz-latn-uz.modernwpf.resources", "costura.uz-latn-uz.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("vi-vn.modernwpf.controls.resources", "costura.vi-vn.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("vi-vn.modernwpf.resources", "costura.vi-vn.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("zh-cn.modernwpf.controls.resources", "costura.zh-cn.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("zh-cn.modernwpf.resources", "costura.zh-cn.modernwpf.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("zh-tw.modernwpf.controls.resources", "costura.zh-tw.modernwpf.controls.resources.dll.compressed");
			AssemblyLoader.assemblyNames.Add("zh-tw.modernwpf.resources", "costura.zh-tw.modernwpf.resources.dll.compressed");
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00003778 File Offset: 0x00001978
		public static void Attach()
		{
			if (Interlocked.Exchange(ref AssemblyLoader.isAttached, 1) == 1)
			{
				return;
			}
			AppDomain currentDomain = AppDomain.CurrentDomain;
			currentDomain.AssemblyResolve += AssemblyLoader.ResolveAssembly;
		}

		// Token: 0x04000019 RID: 25
		private static object nullCacheLock = new object();

		// Token: 0x0400001A RID: 26
		private static Dictionary<string, bool> nullCache = new Dictionary<string, bool>();

		// Token: 0x0400001B RID: 27
		private static Dictionary<string, string> assemblyNames = new Dictionary<string, string>();

		// Token: 0x0400001C RID: 28
		private static Dictionary<string, string> symbolNames = new Dictionary<string, string>();

		// Token: 0x0400001D RID: 29
		private static int isAttached;
	}
}
