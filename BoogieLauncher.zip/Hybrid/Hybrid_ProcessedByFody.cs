﻿using System;

// Token: 0x0200000B RID: 11
internal class Hybrid_ProcessedByFody
{
	// Token: 0x0400001E RID: 30
	internal const string FodyVersion = "6.5.5.0";

	// Token: 0x0400001F RID: 31
	internal const string Costura = "5.7.0";
}
