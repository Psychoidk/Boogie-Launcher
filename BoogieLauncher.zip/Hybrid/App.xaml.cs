﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace Hybrid
{
	// Token: 0x02000004 RID: 4
	public partial class App : Application
	{
	}
}
