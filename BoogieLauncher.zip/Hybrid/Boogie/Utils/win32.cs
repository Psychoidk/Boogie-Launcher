﻿using System;
using System.Runtime.InteropServices;

namespace Boogie.Utils
{
	// Token: 0x02000002 RID: 2
	internal class win32
	{
		// Token: 0x06000002 RID: 2
		[DllImport("kernel32.dll")]
		public static extern IntPtr OpenThread(int dwDesiredAccess, bool bInheritHandle, int dwThreadId);

		// Token: 0x06000003 RID: 3
		[DllImport("kernel32.dll")]
		public static extern int SuspendThread(IntPtr hThread);

		// Token: 0x06000004 RID: 4
		[DllImport("kernel32.dll")]
		public static extern int ResumeThread(IntPtr hThread);

		// Token: 0x06000005 RID: 5
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool AllocConsole();

		// Token: 0x06000006 RID: 6
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool SetConsoleCtrlHandler(win32.HandlerRoutine HandlerRoutine, bool Add);

		// Token: 0x06000007 RID: 7
		[DllImport("kernel32.dll")]
		public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		// Token: 0x06000008 RID: 8
		[DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
		public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

		// Token: 0x06000009 RID: 9
		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x0600000A RID: 10
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x0600000B RID: 11
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

		// Token: 0x0600000C RID: 12
		[DllImport("kernel32.dll")]
		public static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

		// Token: 0x04000001 RID: 1
		public const int PROCESS_CREATE_THREAD = 2;

		// Token: 0x04000002 RID: 2
		public const int PROCESS_VM_OPERATION = 8;

		// Token: 0x04000003 RID: 3
		public const int PROCESS_VM_WRITE = 32;

		// Token: 0x04000004 RID: 4
		public const int PROCESS_VM_READ = 16;

		// Token: 0x04000005 RID: 5
		public const int PROCESS_QUERY_INFORMATION = 1024;

		// Token: 0x04000006 RID: 6
		public const uint PAGE_READWRITE = 4U;

		// Token: 0x04000007 RID: 7
		public const uint MEM_COMMIT = 4096U;

		// Token: 0x04000008 RID: 8
		public const uint MEM_RESERVE = 8192U;

		// Token: 0x02000003 RID: 3
		// (Invoke) Token: 0x0600000F RID: 15
		public delegate bool HandlerRoutine(int dwCtrlType);
	}
}
